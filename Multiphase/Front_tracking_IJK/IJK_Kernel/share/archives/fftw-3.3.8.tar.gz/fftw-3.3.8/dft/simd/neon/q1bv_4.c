/* Generated automatically.  DO NOT EDIT! */
#define SIMD_HEADER "simd-support/simd-neon.h"
#include "../common/q1bv_4.c"
